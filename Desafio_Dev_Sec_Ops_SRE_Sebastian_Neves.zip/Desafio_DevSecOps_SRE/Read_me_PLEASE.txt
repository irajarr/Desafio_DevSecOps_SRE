Projeto de Infraestrutura com Docker e Kubernetes
Autor: Mateus Sebastian Rodrigues da Silva Neves

Data: 19/07/2025 concluído exatamente as 14:36:05

Este projeto implementa uma solução completa para combinação de containers, incluindo:

Docker Compose 

Kubernetes 

Pipeline CI/CD automatizado

Sistema de monitoramento integrado


Configuração do Ambiente:

Pré-requisitos:

Docker 20.10 ou superior

Docker Compose 1.29 ou superior

Minikube/Kind

Git

Cenário 1: Docker Compose
Arquitetura:

Serviço Python (Flask)

Banco PostgreSQL

Como executar:

bash
cd cenario1
docker-compose up --build -d

Verificação:

bash
curl http://localhost:5000 || docker-compose logs web
 Cenário 2: Kubernetes
Componentes criados:

Deployment com 2 réplicas

Service NodePort

ConfigMap e Secret

Comandos-chave:

bash
minikube start
kubectl apply -f cenario2/
kubectl get pods -w
Atualização dinâmica:

bash
kubectl edit configmap app-config
 Cenário 3: CI/CD
Fluxo implementado:

Trigger em merges para main

Build da imagem Docker

Testes unitários

Push para registry

Arquivo: .github/workflows/deploy.yml

 Cenário 4: Monitoramento
Stack proposta:

Ferramenta	Função
Prometheus	Coleta de métricas
Grafana	        Visualização
cAdvisor	Monitoramento de containers

Implementação:

bash
docker-compose -f cenario4/monitoring.yml up -d
Boas Práticas de Segurança
Uso de secrets do Kubernetes

Imagens oficiais validadas

Controle de acesso via RBAC

Scan de vulnerabilidades no CI

Todos os arquivos de configuração estão documentados

Scripts incluem tratamento de erros


